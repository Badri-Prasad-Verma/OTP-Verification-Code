package com.OTPSending;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OtpSendingApplication {

	public static void main(String[] args) {
		SpringApplication.run(OtpSendingApplication.class, args);
	}

}
